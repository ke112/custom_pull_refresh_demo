
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

class CommonSliverPersistentHeaderDelegate extends SliverPersistentHeaderDelegate {
  final double minHeight;
  final double maxHeight;
  final Widget child;
  final bool isAtMinHeight;

  CommonSliverPersistentHeaderDelegate({
    required this.minHeight,
    required this.maxHeight,
    required this.child,
    required this.isAtMinHeight,
  });

  @override
  Widget build(BuildContext context, double shrinkOffset, bool overlapsContent) {
    // 如果已经吸顶，强制限制最大高度为 minHeight，并显示底部内容
    if (isAtMinHeight) {
      return GestureDetector(
        behavior: HitTestBehavior.translucent,
        onVerticalDragStart: (_) {}, // 拦截垂直滑动
        onVerticalDragUpdate: (_) {}, // 拦截垂直滑动
        onVerticalDragEnd: (_) {}, // 拦截垂直滑动
        onTap: () {}, // 拦截点击
        onDoubleTap: () {}, // 拦截双击
        onLongPress: () {}, // 拦截长按
        child: SizedBox(
          height: minHeight,
          child: OverflowBox(
            alignment: Alignment.topCenter,
            maxHeight: maxHeight,
            child: Transform.translate(
              offset: Offset(0, -maxHeight + minHeight),
              child: child,
            ),
          ),
        ),
      );
    }

    // 未吸顶时的正常滚动行为
    final double currentHeight = (maxHeight - shrinkOffset).clamp(minHeight, maxHeight);
    final double offset = -(shrinkOffset / (maxHeight - minHeight)).clamp(0.0, 1.0) * (maxHeight - minHeight);

    return SizedBox(
      height: currentHeight,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned(
            top: offset,
            left: 0,
            right: 0,
            child: SizedBox(
              height: maxHeight,
              child: child,
            ),
          ),
        ],
      ),
    );
  }

  @override
  double get maxExtent => isAtMinHeight ? minHeight : maxHeight;

  @override
  double get minExtent => minHeight;

  @override
  bool shouldRebuild(CommonSliverPersistentHeaderDelegate oldDelegate) {
    return minHeight != oldDelegate.minHeight ||
        maxHeight != oldDelegate.maxHeight ||
        child != oldDelegate.child ||
        isAtMinHeight != oldDelegate.isAtMinHeight;
  }

  @override
  FloatingHeaderSnapConfiguration? get snapConfiguration => null; // 禁用浮动头部的自动吸附

  @override
  OverScrollHeaderStretchConfiguration? get stretchConfiguration => null; // 禁用过度滚动时的拉伸效果
}
