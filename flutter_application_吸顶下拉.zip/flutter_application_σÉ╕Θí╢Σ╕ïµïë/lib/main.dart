import 'package:flutter/material.dart';
import 'package:flutter_application_1/common_sliver_persistent_header_delegate.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // TRY THIS: Try running your application with "flutter run". You'll see
        // the application has a purple toolbar. Then, without quitting the app,
        // try changing the seedColor in the colorScheme below to Colors.green
        // and then invoke "hot reload" (save your changes or press the "hot
        // reload" button in a Flutter-supported IDE, or press "r" if you used
        // the command line to start the app).
        //
        // Notice that the counter didn't reset back to zero; the application
        // state is not lost during the reload. To reset the state, use hot
        // restart instead.
        //
        // This works for code too, not just values: Most code changes can be
        // tested with just a hot reload.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final ScrollController _scrollController = ScrollController();
  final RefreshController _refreshController = RefreshController(initialRefresh: false);

  bool _isAtMinHeight = false;

  /// 浮窗图层
  OverlayEntry? overlayEntry;

  List<String> items = ["1", "2", "3", "4", "5", "6", "7", "8"];

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    final bool isAtMinHeight = _scrollController.offset >= 100;
    // 一旦设置为 true，就保持这个状态，除非通过点击状态栏重置
    if (!_isAtMinHeight && isAtMinHeight && !_isAtMinHeight) {
      _isAtMinHeight = true;
      print('固定吸顶了: $_isAtMinHeight');
    }
  }

  void _onRefresh() async {
    // monitor network fetch
    await Future.delayed(const Duration(milliseconds: 1000));
    // if failed,use refreshFailed()
    items.add((items.length + 1).toString());
    if (mounted) setState(() {});
    _refreshController.refreshCompleted();
  }

  void _onLoading() async {
    // monitor network fetch
    await Future.delayed(const Duration(milliseconds: 1000));
    // if failed,use loadFailed(),if no data return,use LoadNodata()
    items.add((items.length + 1).toString());
    if (mounted) setState(() {});
    _refreshController.loadComplete();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          SafeArea(bottom: false, child: _buildSliver()),
          Builder(builder: (context) {
            WidgetsBinding.instance.addPostFrameCallback((_) {
              _showOverlay(context);
            });
            return Container();
          }),
        ],
      ),
    );
  }

  /// 构建滚动视图
  Widget _buildSliver() {
    return NestedScrollView(
      controller: _scrollController,
      headerSliverBuilder: (context, innerBoxIsScrolled) {
        return [
          SliverPersistentHeader(
            pinned: true,
            delegate: CommonSliverPersistentHeaderDelegate(
              minHeight: 100,
              maxHeight: 200,
              isAtMinHeight: _isAtMinHeight,
              child: Container(
                color: Colors.green,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    ListView.builder(
                      scrollDirection: Axis.vertical,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: 10,
                      itemBuilder: (BuildContext context, int index) {
                        return Container(
                          height: 20,
                          alignment: Alignment.centerLeft,
                          padding: const EdgeInsets.only(left: 16),
                          child: Text(
                            '$index',
                            style: const TextStyle(color: Colors.white),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ),
        ];
      },
      body: _buildSmartRefresher(),
    );
  }

  Widget _buildSmartRefresher() {
    return SmartRefresher(
      enablePullDown: true,
      // enablePullUp: true,
      header: const ClassicHeader(),
      controller: _refreshController,
      onRefresh: _onRefresh,
      // onLoading: _onLoading,
      child: sHomeNewContent(),
    );
  }

  Widget sHomeNewContent() {
    return ListView.builder(
      padding: EdgeInsets.zero,
      itemCount: 30,
      itemExtent: 100,
      itemBuilder: (BuildContext context, int index) {
        return GestureDetector(
          behavior: HitTestBehavior.translucent,
          onTap: () async {
            print('点击');
          },
          child: Container(
            color: Colors.grey,
            padding: EdgeInsets.only(left: 20),
            child: Text('$index'),
          ),
        );
      },
    );
  }

  void _showOverlay(BuildContext context) {
    OverlayState? overlayState = Overlay.of(context);
    if (overlayEntry != null) {
      overlayEntry!.remove();
      overlayEntry = null;
    }
    overlayEntry = OverlayEntry(
      builder: (context) => Positioned(
        top: 0,
        left: 0,
        right: 0,
        child: GestureDetector(
          onTap: () {
            resumeDefault();
          },
          child: Container(
            height: MediaQuery.of(context).padding.top,
            color: Colors.white,
          ),
        ),
      ),
    );
    overlayState.insert(overlayEntry!);
  }

  void resumeDefault() {
    if (_scrollController.offset == 0 && _isAtMinHeight == false) {
      print('已经到达顶部');
      return;
    }
    setState(() {
      _isAtMinHeight = false;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeInOut,
        );
      }
    });
  }
}
